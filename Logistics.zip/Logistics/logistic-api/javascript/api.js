var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
const port = 5000;
// const asset = require('/home/ubu/fabric-samples/chaincode/logistic/lib/Assets.js');



var app = express();
app.use(bodyParser.json());
app.options('*', cors());
app.use(cors());

// Setting for Hyperledger Fabric

const { Wallets, Gateway, } = require('fabric-network');
const path = require('path');
const fs = require('fs');
const yaml = require('js-yaml');
const ccpPath = path.resolve(__dirname, '..','..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org2.example.com', 'connection-org2.yaml');
console.log(ccpPath,"testingg path")


app.get('/', (req, res) => res.send('Welcome to logistic-trade Api Application Using Blockchain!'))
       
app.post('/api/initledger', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), './../../ORG_A/identity/user');
        console.log(walletPath,"walletpath")
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const identity = await wallet.get('isabella');
        if (!identity) {
            console.log('An identity for the user "isabella" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        console.log("##########");

        let connectionProfile = yaml.safeLoad(fs.readFileSync('../../../test-network/organizations/peerOrganizations/org2.example.com/connection-org2.yaml', 'utf8'));

        // Set connection options; identity and wallet
        let connectionOptions = {
            identity: 'isabella',
            wallet: wallet,
            discovery: { enabled:true, asLocalhost: true }
        };

        // Connect to gateway using application specified parameters
        console.log('Connect to Fabric gateway.');

        await gateway.connect(connectionProfile, connectionOptions);


        console.log("##########");
        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel');
        console.log("$$$$$$$");
        console.log("$$$$$$$",network);

        // Get the contract from the network.
        const contract = network.getContract('papercontract');
  

        // var tradeData = asset.Trade;
        var tradeData1 = req.body;
        // tradeData.Initledger.exportersBank = req.body.exportersBankName;
        // tradeData.Initledger.exportersAccountBalance = req.body.exportersAccountBalance;
        // tradeData.Initledger.importer = req.body.importerName;
        // tradeData.Initledger.importersBank = req.body.importersBankName;
        // tradeData.Initledger.importersAccountBalance = req.body.importersAccountBalance;
        // tradeData.Initledger.carrier = req.body.carrierName;
        // tradeData.Initledger.regulatoryAuthority = req.body.regulatorName;
        // tradeData.flag = req.body.flag;
        // tradeData.tradeId = req.body.tradeId;
        console.log("$$$$", tradeData1);
        //await contract.submitTransaction('invoke',initledger.Participants.ImportersBank);
        await contract.submitTransaction('invoke', JSON.stringify(tradeData1));
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);

    }
});

app.post('/api/initledger1', async function (req, res) {
    try {

        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user3');
        if (!userExists) {
            console.log('An identity for the user "user3" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccpPath, { wallet, identity: 'user3', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('two');
        console.log("$$$$$$$");
        // Get the contract from the network.
        const contract = network.getContract('tradecc');

        // var tradeData = asset.Trade;
        var tradeData1 = req.body;
        // tradeData.Initledger.exportersBank = req.body.exportersBankName;
        // tradeData.Initledger.exportersAccountBalance = req.body.exportersAccountBalance;
        // tradeData.Initledger.importer = req.body.importerName;
        // tradeData.Initledger.importersBank = req.body.importersBankName;
        // tradeData.Initledger.importersAccountBalance = req.body.importersAccountBalance;
        // tradeData.Initledger.carrier = req.body.carrierName;
        // tradeData.Initledger.regulatoryAuthority = req.body.regulatorName;
        // tradeData.flag = req.body.flag;
        // tradeData.tradeId = req.body.tradeId;
        console.log("$$$$", tradeData1);
        //await contract.submitTransaction('invoke',initledger.Participants.ImportersBank);
        await contract.submitTransaction('invoke', JSON.stringify(tradeData1));
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();

    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);

    }
});





app.listen(port, () => console.log(`logistic-trade  app listening on port ${port}!`))

