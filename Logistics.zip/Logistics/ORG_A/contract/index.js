/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const logisticchaincode = require('./lib/workflow');

module.exports.logisticchaincode = logisticchaincode;
module.exports.contracts = [ logisticchaincode ];
